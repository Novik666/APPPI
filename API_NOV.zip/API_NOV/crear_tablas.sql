create table productos(
codigo_p varchar(4),
marca varchar(30),
modelo varchar(30),
color varchar(30),
precio float,
proveedor varchar(30));

insert into productos values
('11AR','Bike','XTKM','Rojo',2501.2,'Homets'),
('12TG','Specialized','Specialized Tarmac','Negro',2222.2,'Ajams'),
('T1AU','Cannondale','Cannondale Scalpel','Verde',5000.2,'Lanscorp');